/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Order;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Dbconn {
    
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/onlineapp";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";
    
    private Connection connection;
    
    
    public Dbconn(){

        try {
                    connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
                    System.out.println("Connected to the database.");
                } catch (SQLException e) {
                    System.err.println("Error connecting to the database: " + e.getMessage());
                }
        }
    
    
     public Connection getConnection() {
        return connection;
    }
     
     public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Connection closed.");
            }
        } catch (SQLException e) {
            System.err.println("Error closing the connection: " + e.getMessage());
        }
    }


}
